#ifndef TOUR_H
#define TOUR_H

#define MAX_TOUR_SPEED 100

#endif
