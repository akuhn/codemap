#ifndef READ_CSV_H
#define READ_CSV_H
gboolean isCSVFile (const gchar * fileName, ggobid * gg, GGobiPluginInfo * plugin);
#endif
